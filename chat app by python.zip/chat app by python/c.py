import socket
import threading
import tkinter as tk
from tkinter import *

# function tjib les message mn server 7ta ydiconnecti client
def receive_message(sock):
    while True:
        try:
            # yst9bl les message mn server w ydir update l chat box 
            message = sock.recv(1024).decode()
            update_chat_box(message)
        except:
            # fi 7alt server diconnecta yafichi lmessage w تتقفل la socket 
            print("Disconnected from the server.")
            sock.close()
            break

# function dir update l chat
def update_chat_box(message, sender="Server"):
    # Enable text editing, insert the message, auto-scroll to the end, and disable text editing again
    chat_box.config(state=tk.NORMAL) # t9dr tktb 
    if sender == "You":
        # yaficher text f interface
        chat_box.insert(tk.END, f"You: {message}\n")
    else:
        chat_box.insert(tk.END, f"{sender}: {message}\n")

    chat_box.yview(tk.END)  # Auto-scrolls to the end
    chat_box.config(state=tk.DISABLED) # ydisactivi edit 3la text f interface

# function tb3t les message l server 
def send_message(event=None):
    message = message_entry.get() # engestrer text lktbo the clinet  
    update_chat_box(message, "You") # update l chat box w y7t ism lb3t message "You"
    client_socket.send(message.encode()) # yb3t text l server mchfri
    message_entry.delete(0, tk.END) # yn7i message mn input 

# main 

# create a client socket and connect to the server
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = "localhost"
port = 15555
client_socket.connect((host, port))

root = tk.Tk() # create window 
root.title("Chat Client") # title for window

# Create a Text widget for displaying chat messages
chat_box = Text(root, width=40, height=15) # dimention ta3 textarea
chat_box.grid(row=0, column=0, columnspan=2, padx=10, pady=10) # dimention ta3 window
chat_box.config(state=tk.DISABLED)  # ydisactici modification 3la text f chatbox

# create input
message_entry = Entry(root, width=30)
message_entry.grid(row=1, column=0, padx=10, pady=10) # dimention ta3 input
message_entry.bind("<Return>", send_message)  

# Create a Button for sending messages
send_button = Button(root, text="Send", command=send_message) # create button send w ki tcliki 3lih yb3t message b function send_message
send_button.grid(row=1, column=1, pady=10) # dimention ta3 button 

# yst9bl les message mn server 7ta tt9fl intreface
threading.Thread(target=receive_message, args=(client_socket,)).start()

# y93d ydir update l intreface
root.mainloop()
