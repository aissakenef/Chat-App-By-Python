import socket
import threading

# ykhbi les client li mconnctyin
clients = []

# function tgere les communication ta3 client
def client_thread(conn, addr):
    conn.send("Connected to the chat server!".encode()) # afficher message l client bli connecta m3a srever 
    # boucle tst9bl w tb3t les message 
    while True:
        try:
            # yst9bl message mn client 
            message = conn.recv(1024).decode()
            if message:
                # yktb message lb3to client w laddress ta3o 
                print(f"{addr} says: {message}")
                broadcast(message, conn)
            else:#-----------------------------------------------------------------------------------------------
                remove_connection(conn)
                break
        except:
            # ykml exucuti boucle nrml fi un cas exception par ex : client diconnecte
            continue  

#function hdi bach tb3t message l client lkaml apare client lb3t message  
def broadcast(message, connection):
    for client in clients: # boucle hdi tjib les client l kayn 
        if client != connection: # boucle hdi bach my3awdch yb3t message l nfs client 
            try:
                # Send the message
                client.send(message.encode())
            except:
                # k ydiconnecti client yn7ih servereur mn la list ta3 les clients 
                client.close()
                remove_connection(client)

# function supprimer le client mn la list ta3 les les client
def remove_connection(conn):
    if conn in clients: # testi lkan client mconnecti wla nn
        clients.remove(conn) # Yn7i client mn la list 

# main 

# create socket
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# yrbt socket m3a les interface l kayn
server.bind(('', 15555))
# k yousl 100 request f w9t wa7d server my9bl 7ta wa7d
server.listen(100)

print("Waiting for connection...") 

# loop accept the clients
while True:
    # Accept a new connection request
    conn, addr = server.accept()
    # Add the new client l la list ta3 les clients 
    clients.append(conn)
    # afficher message bli client connecta
    print(addr[0] + " connected")

    # server y geri les clients kaml bla ma ybloki 7ta client 
    threading.Thread(target=client_thread, args=(conn, addr)).start()